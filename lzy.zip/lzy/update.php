<?php 
    require_once "./conn.php";

    if (isset($_POST['article'])&&isset($_POST['title'])) {
        $title=$_POST['title'];
        $article=$_POST['article'];
        $id=$_GET['id'];
    }

    $sql="update text set article ='{$article}',title='{$title}' where text_id='{$id}'";
    $rs=$pdo->query($sql);
    if ($rs) {
        echo "<script>alert('修改成功');</script>";
        header('Location:./index.php');
    }
    var_dump($rs);
 ?>