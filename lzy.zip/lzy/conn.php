<?php 
$localhost="mysql:host=localhost;dbname=luntan";
$user="root";
$password="lllc5552";
$db=new PDO($localhost,$user,$password);
$db->query("set names utf8");
 ?>