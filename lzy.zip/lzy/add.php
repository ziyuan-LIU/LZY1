<?php 
    session_start();
    require_once "./conn.php";
    if (isset($_POST['title'])||isset($_POST['article'])) {
        $title=$_POST['title'];
        $article=$_POST['article'];
        $time=date("Y-m-d H:i:s");
        $user=$_SESSION['name'];
    }
    $sql="insert into tb_article(article_title,article,article_submitTime,article_aurthor) value('$title','$article','$time','$user')";
    $rs=$pdo->exec($sql);
    if ($rs>0) {
        echo "<script>alert('插入成功');</script>";
        header('Location:./index.php');
    }
 ?>