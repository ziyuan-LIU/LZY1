<?php 
    require_once "./conn.php";
    session_start();
    if (isset($_POST['name'])&&isset($_POST['password'])&&$_POST['sex']) {
        $user=htmlspecialchars($_POST['name']);
        $password=sha1(htmlspecialchars($_POST['password']));
        if ($_POST['sex']%2==0) {
            $sex=0;
        }else{
            $sex=1;
        }
        @$phone=htmlspecialchars($_POST['phone']);
        @$email=htmlspecialchars($_POST['email']);
    }else{
        echo "<script>alert('基本信息不得为空');window.history.go(-1);</script>";
    }

    $testsql="select user,sex from admin where user='{$user}' and sex='{$sex}'";
    $ry=$pdo->query($testsql);
    $row=$ry->fetch(PDO::FETCH_ASSOC);
    if (!is_null($row[0])) {
        echo "<script>alert('用户已存在');window.history.go(-1);";
    }else{

    $sql="insert into admin(user,pwd,tel,email,sex) values('{$user}','{$password}','{$phone}','{$email}','{$sex}')";
    $rs=$pdo->query($sql);
    var_dump($sql);
    if ($rs>0) {
        echo "<script>alert('注册成功');</script>";
        $_SESSION['name']=$name;
        header('Location:./index.php');
    }else{
        echo "<script>alert('服务器出错，请重试');</script>";
    }
}