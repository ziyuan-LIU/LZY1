<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style type="text/css">
     body{
        padding: 0;
        margin: 0;
        width: 1200px;
        height: 300px;
        font-family: "幼圆";
     }
     .title{
        border:1px solid none;
        margin: 0 auto;
        border-left: 3px solid #ffbf5b;
        margin-left: 30px;
     }
     .container{
        border: 1px solid #ffbf5b;
        margin: 0 auto;
        width: 600px;
        height: 550px;
     }
     .title p{
        margin-left: 180px;
        font-size: 60px;
        font-family: "幼圆";
        font-weight: bolder;
        color: #ffbf5b;
        letter-spacing: 2px;
     }
     hr{
        width: 580px;
        margin-bottom: -106px;
        color: #ffbf5b;
     }
     img{
        width: 28px;
        height: 30px;
        margin-left: 252px;
     }
     form{
        margin-top: 150px;
        margin-left: 20px;
     }
     input,label{
        display: block;
        margin-left: 125px;
        margin-top: 5px;
             }
     input[type="text"],
     input[type="password"]{
        width: 300px;
        height: 15px;
        border-radius: 5px;
        outline: none;
        padding: 2px 4px;
        border:1px solid #ffbf5b;
     }
     input[type="submit"]{
        width: 312px;
        height: 35px;
        font-size: 20px;
        margin-top: 20px; 
        cursor: pointer;
        color: white;
        background-color: #ffbf5b;
        outline: none;
        border: none;
        font-family: "幼圆";
        border-radius: 5px;
        margin-bottom: 2px;
        margin-top: -1px;
     }
     a{
        text-decoration: none;
        margin-top: 20px;
        margin-left: 400px;
        color: #ffbf5b;
     }
    </style>
</head>
<body>
<div class="container">
<div class="title">
    <p>LOGIN</p>
</div>
    <hr>
    <img src="img/微信图片_20170421003204.png">
    <form action="./login_all.php"method="post">
        <label for="usingname">用 户</label>
        <input type="text" name="name"/>
        <label for="password">密 码</label>
        <input type="password" name="password">
        <input type="submit" value="登 录" >
        </form>
    <a href="./register.php">还没账号？</a>
</div>
</script>
</body>
</html>