<?php 
    session_start();
    if (empty($_SESSION['name'])) {
        header("Location:./login.php");
    }
    header("Content-Type:text/html;charset=UTF-8");
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <?php  
    if (isset($_GET['id'])) {
        $id=$_GET['id'];
        $sql="select * from tb_article where id={$article_id}";
        $rs=$pdo->query($sql);
        if ($rs) {
            $row = $rs->fetch(PDO::FETCH_ASSOC); 
                echo <<<STR
                    <div class="title">
                        {$row['article_title']}
                    </div>
                    <div class="text">
                        {$row['article']}
                    </div>
STR;
           }   
    }
         ?>
    </body>
    </html>