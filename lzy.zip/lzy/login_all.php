<?php
//开启session事务的操作
session_start();
require_once "./conn.php";

//获取从前端POST来的值,记得过滤，作为一个后端，绝对不能信任前端传递过来的值
if (isset($_POST['name'])&&isset($_POST['password'])) {
    $user=htmlspecialchars($_POST['name']);
    //用sha1来进行加密更保险
    $password=sha1(htmlspecialchars($_POST['password']));
}else{
    //判断为空时执行如下语句
    var_dump($_POST['password']);
    echo "<script>alert('基本信息不得为空');window.history.go(-1);</script>";
}

//与数据库中的数据进行比较
$sql="select user,pwd from admin where user='{$user}' and pwd='{$password}'";
//执行句柄
$rs=$pdo->query($sql);
// $row=$rs->fetch(PDO::FETCH_ASSOC);
var_dump($rs);
if ($rs) {
    $_SESSION['name']=$user;
    header('Location:./index.php');
}else{
    echo "<script>alert('服务器出错');window.history.go(-1);</script>";
}