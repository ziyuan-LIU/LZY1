<?php 
    session_start();
    require_once "./conn.php";
    if (empty($_SESSION['name'])) {
        header("Location:./login.php");
    }
    header("Content-Type:text/html;charset=UTF-8");
    ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style type="text/css">
        th,td{
            border: 1px black,solid;
        }
        a{
            text-decoration: none;
        }
    </style>
</head>
<body>
    <table style="border: 1px black solid;">
        <tr style="border: 1px black solid;">
            <th>编号</th>
            <th>标题</th>
            <th>内容</th>
            <th>发表日期</th>
            <th>作者</th>
            <th>操作</th>
            <th><a href="./articleadd.php">发表文章</a></th>
        </tr>
        <tr>
            <?php
                $sql="select * from text where user='{$_SESSION['name']}'";
                $rs=$pdo->query($sql);
                if ($rs) {
                // $row=$rs->fetch(PDO::FETCH_ASSOC);
                    while ($row=$rs->fetch(PDO::FETCH_ASSOC)) {
                        echo <<<STR
                            <a href="./detail.php?id={$row['text_id']}"><td>{$row['text_id']}</td></a>
                            <a href="./detail.php?id={$row['text_id']}"><td>{$row['title']}</td></a>
                            <a href="./detail.php?id={$row['text_id']}"><td>{$row['article']}</td></a>
                            <a href="./detail.php?id={$row['text_id']}"><td>{$row['date']}</td></a>
                            <a href="./detail.php?id={$row['text_id']}"><td>{$row['user']}</td></a>
                            <td><a href="./articleupdate.php?id={$row['text_id']}">修改</a></tr><br>
STR;
                    }
                }
            ?>
        </tr>
    </table>
</body>
</html>