<?php 
    session_start();
    if (empty($_SESSION['name'])) {
        header("Location:./login.php");
    }
    header("Content-Type:text/html;charset=UTF-8");
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <title>Document</title>
        <style type="text/css">
            div{
                width: 1000px;
                margin: 0 auto;
            }
            input[type="text"]{
                position: relative;
                left: 30%;
                width: 500px;
                margin-bottom: 20px;
            }
            input[type="submit"]{
                position: absolute;
                right: 100px;
            }
        </style>
    </head>
    <body>
    <div>
    <form action="./add.php">
        <input type="text" placeholder="标题" name="title">
        <textarea name="article" id="" cols="150" rows="50">
            
        </textarea>
        <input type="text" name="aurthor" placeholder="作者">
        <input type="submit" value="提交">
    </form>
    </div>
    </body>
    </html>