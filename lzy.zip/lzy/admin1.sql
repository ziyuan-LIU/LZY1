-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2018-06-25 13:35:43
-- 服务器版本： 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin1`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

CREATE TABLE `admin` (
  `aid` int(10) UNSIGNED NOT NULL,
  `user` char(50) NOT NULL,
  `pwd` char(50) NOT NULL,
  `tel` int(11) DEFAULT NULL,
  `email` char(50) DEFAULT NULL,
  `sex` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`aid`, `user`, `pwd`, `tel`, `email`, `sex`) VALUES
(1, 'a123', '202cb962ac59075b964b07152d234b70', 1, '12345678910', 0),
(2, 'aaa', '47bce5c74f589f4867dbd57e9ca9f808', 1, '12231231231', 1313),
(3, 'qqq', 'b2ca678b4c936f905fb82f2733f5297f', 1, '11111111111', 0),
(4, '你好', 'dc483e80a7a0bd9ef71d8cf973673924', 1, '12345678901', 0),
(5, '吴桐', '202cb962ac59075b964b07152d234b70', 1, '12234567890', 0),
(6, 'bbb', '4d9012b4a77a9524d675dad27c3276ab5705e5e8', 1234567890, '342501293@qq.com', 1),
(8, 'ccc', 'f36b4825e5db2cf7dd2d2593b3f5c24c0311d8b2', 1, '1', 1),
(9, 'ddd', '9c969ddf454079e3d439973bbab63ea6233e4087', 2, '2', 0);

-- --------------------------------------------------------

--
-- 表的结构 `text`
--

CREATE TABLE `text` (
  `text_id` int(10) UNSIGNED NOT NULL,
  `aid` int(11) NOT NULL,
  `title` char(30) NOT NULL,
  `article` tinytext NOT NULL,
  `date` date NOT NULL,
  `user` char(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `text`
--

INSERT INTO `text` (`text_id`, `aid`, `title`, `article`, `date`, `user`) VALUES
(0, 1, '第一篇文章', '谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢', '2017-06-23', 'bbb'),
(1, 2, 'zxc', '你好', '2017-06-22', 'bbb'),
(2, 3, 'axv', 'bzvbv', '2017-06-22', 'aaa'),
(5, 4, '测试2', '这是测试2', '2017-06-22', '吴桐'),
(6, 5, '继续写文章', '阿萨德若', '2017-06-22', '吴桐'),
(7, 8, '一个简单的js', '<script>\r\n   alert(1);\r\n</script>', '2017-06-22', '吴桐'),
(8, 9, 'axdfadfaaaaaaaaaaaaaaaaaaaaasd', 'xavzcvdafga', '2017-06-22', '吴桐'),
(9, 10, 'adfada', 'z vzxvzxfas', '2017-06-22', '吴桐'),
(10, 11, 'qweafasfasfg', 'axvadfgqetqeg', '2017-06-22', '吴桐'),
(12, 12, '继续写测试', '谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢谢', '2017-06-22', '吴桐'),
(13, 14, '凑文章', '我在凑文章', '2017-06-22', '吴桐'),
(14, 15, '继续凑文章', '凑凑凑', '2017-06-22', '吴桐'),
(15, 16, '               hello', '自行车', '2017-06-22', '吴桐'),
(16, 17, '一个js程序', '<script>\r\n     alert(1);\r\n</script>', '2017-06-23', 'aaa'),
(17, 18, '测试', 'a  a', '2017-06-23', 'aaa'),
(19, 20, 'asf', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '2017-06-23', 'aaa'),
(20, 21, '非常长的标题非常长的标题非常长的标题非常长的标题非常长的标题', 'adsfasdf', '2017-06-23', 'aaa'),
(21, 22, '习近平深入吕梁调研深度贫困地区脱贫攻坚大计', '习近平看望晋绥边区老战士\r\n6月21日上午，习近平总书记到山西考察调研，在晋绥军区司令部旧址，总书记同当年在晋绥边区参加对敌斗争的老战士们亲切交谈。习近平说，吕梁我是第一次来，', '2017-06-23', 'aaa'),
(22, 23, 'zzzzxchrfhaatrwg', 'asdfsdfsdfs', '2017-06-23', 'qqq'),
(23, 24, '水调歌头我大概', '是单个市场部v干啥打公会我顶塔提前儿童', '2017-06-23', 'qqq'),
(24, 25, 'zxvryeryeryery', 'cvgjfgdhjdfhjdfryiuvbmgfkj', '2017-06-23', 'aaa'),
(25, 26, '一个简单的js程序', '<script>\r\n     alert("hello");\r\n</script>', '2017-06-23', 'aaa'),
(26, 27, 'sf', 'saf', '2017-06-23', 'aaa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `text`
--
ALTER TABLE `text`
  ADD PRIMARY KEY (`text_id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- 使用表AUTO_INCREMENT `text`
--
ALTER TABLE `text`
  MODIFY `text_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
