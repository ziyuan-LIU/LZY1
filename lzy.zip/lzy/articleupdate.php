<?php 
    session_start();
    require_once "./conn.php";
    if (empty($_SESSION['name'])) {
        header("Location:./login.php");
    }
    header("Content-Type:text/html;charset=UTF-8");
    if (isset($_GET['id'])) {
            $id=$_GET['id'];
        }
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <title>Document</title>
        <style type="text/css">
            div{
                width: 1000px;
                margin: 0 auto;
            }
            input[type="text"]{
                position: relative;
                left: 30%;
                width: 500px;
                margin-bottom: 20px;
            }
            input[type="submit"]{
                position: absolute;
                right: 100px;
            }
        </style>
    </head>
    <body>
    <div>
    <form action="./update.php?id=<?php echo $id;?>" method="post">
    <?php 
        $sql="select * from text where text_id='{$id}'";
        $rs=$pdo->query($sql);
        $row=$rs->fetch(PDO::FETCH_ASSOC);
     ?>
        <input type="text" value="<?php echo $row['title']; ?>" name="title">
        <textarea name="article" id="" cols="150" rows="50" value="<?php echo $row['article'] ?>">
            <?php echo $row['article']; ?>"
        </textarea>
        <input type="text" name="aurthor" value="<?php echo $row['user'] ?>">
        <input type="submit" value="提交">
    </form>
    </div>
    </body>
    </html>