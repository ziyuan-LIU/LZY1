<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>登录注册</title>
  <style type="text/css">
   body{
        background-color: #DCDCDC;
        margin:0;
        padding:0;
        font-family: "Microsoft Yahei";
      }
    .contain{
      width: 400px;
      height: 500px;
      border: 1px solid black;
      margin:100px auto;

    }
     .title{
      font-size: 30px;
      padding-left: 25px;
      padding-top: 20px;
       margin-left: 20px;
      border-left: 2px solid black;
       margin-top: 8px;
        height: 50px;  /*border的高度*/     
     
    }
     .one{
     display: block;
     margin-top:30px;


     }
    .one label{
      letter-spacing: 1px;
      font-size: 20px;
      margin-left: 20px;
      padding-top: 5px;
      
    }
    .one label[for="address"]{
      margin-left: 200px;
    }
    .one input[type="text"],
    .one input[type="password"]
     {  
       margin:10px 15px 10px 15px;
       width: 250px;
       padding: 4px;
       height: 20px;
       outline: none;
       order: none;
       font-size:15px;
     }
 .one input[type=submit]{
    width: 380px;
    height: 45px;
    margin-left: 7px;
    margin-top: 5px;
    border-radius: 20px;
    background:#C4C4C4;
    font-size: 20px;
    cursor: pointer;
   }
   .one input[value=" "]
   {width: 70px;
    height: 15px;
    font-size: 20px;
   }
   img{
    margin-bottom: -8px;
    width: 160px;
   }
  </style>
</head>
<body>
  <div class="contain">
  <div class="title">注册界面</div><hr>
  <form  class="one" method="post" action="./register_all.php">
            <label for="username">用户名:</label>
            <input type="text" placeholder="用户名" name="name">
            <label for="password">密 &nbsp;&nbsp;码:</label>
            <input type="password" placeholder="密码" name="password">
            <label for="userphone">电 &nbsp;&nbsp;话:</label>
            <input type="text" placeholder="电话号码" name="phone"> 
             <div><label for="useremail">性 &nbsp;&nbsp;别:</label>
            <input type="radio" value="1" name="sex" checked="true">男
            <input type="radio" value="0" name="sex">女</div>
            <label for="">邮 &nbsp;&nbsp;箱:</label> 
            <input type="text" name="email" placeholder="邮箱">
        <input type="submit" value="立即注册">
            </form>
</div></body>
</html>